﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Test1
{
    /// <summary>
    /// 点名系统
    /// </summary>
    class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            List<User> a = new List<User>()
            {
                new User()
                {
                    xingming = "小虎",
                    xingbie = true,
                    nianling = 18,
                    xiaohonghua = 10
                },
                new User()
                {
                    xingming = "小蛇",
                    xingbie = false,
                    nianling = 17,
                    xiaohonghua = 30
                },
                new User()
                {
                    xingming = "小龙",
                    xingbie = true,
                    nianling = 19,
                    xiaohonghua = 20
                }
            };
            List<User> yd = new List<User>();
            List<User> wd = new List<User>();
            Console.WriteLine("上课了，开始点名了，已到请按1，未到请按任意键");
            a.ForEach(item =>
            {
                Console.WriteLine(item.xingming + "在吗？");
                if (Console.ReadLine() == "1")
                {
                    Console.WriteLine("在");
                    item.xiaohonghua = item.xiaohonghua + 5;
                    yd.Add(item);
                }
                else
                {
                    Console.WriteLine("…………");
                    item.xiaohonghua = item.xiaohonghua - 5;
                    wd.Add(item);
                }
            });
            if (wd.Count > 0)
            {
                Console.WriteLine("下面是未到同学名单");
                wd.ForEach(item =>
                {
                    Console.WriteLine(
                        $"{item.xingming},性别：{(item.xingbie ? "男" : "女")}，年龄:{item.nianling}，小红花数量:{item.xiaohonghua}");
                });
            }
            else
            {
                Console.WriteLine("大家真棒，全部都到齐了，目前大家的信息如下");
                yd.ForEach(item =>
                {
                    Console.WriteLine(
                        $"{item.xingming},性别：{(item.xingbie ? "男" : "女")}，年龄:{item.nianling}，小红花数量:{item.xiaohonghua}");
                });
            }
            Console.WriteLine("按任意键结束");
            Console.ReadKey();
        }

        public class User
        {
            public string xingming { get; set; }

            public bool xingbie { get; set; }

            public int nianling { get; set; }

            public int xiaohonghua { get; set; }
        }
    }
}