﻿using EInfrastructure.Core.Configuration.Enumeration;

namespace SignIn.Domain
{
    /// <summary>
    /// 学生
    /// </summary>
    public class Student : People
    {
        public Student()
        {
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">姓名</param>
        /// <param name="gender">性别</param>
        /// <param name="age">年龄</param>
        /// <param name="scole">小红花数量</param>
        public Student(string name, Gender gender, int age, int scole) : base(name, gender, age)
        {
            Scole = scole;
        }

        #region 更改小红花数量

        /// <summary>
        /// 更改小红花数量
        /// </summary>
        /// <param name="scole">小红花数量</param>
        public void ChangeScole(int scole)
        {
            Scole += scole;
        }

        #endregion

        /// <summary>
        /// 分数
        /// </summary>
        public int Scole { get; private set; }
    }
}