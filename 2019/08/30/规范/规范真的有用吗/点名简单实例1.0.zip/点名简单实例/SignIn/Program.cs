﻿using System;
using System.Collections.Generic;
using EInfrastructure.Core.Configuration.Enumeration;
using SignIn.Domain;

namespace SignIn
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Student> allUserList = Init(); //初始化数据
            List<Student> arrivedStudentList = new List<Student>(); //已到人员集合
            List<Student> noFindStudentList = new List<Student>(); //未到人员集合

            Console.WriteLine("上课了，开始点名了，已到请按1，未到请按任意键");
            
            SignIn(allUserList, user =>
            {
                Console.WriteLine("在");
                user.ChangeScole(+5);
                arrivedStudentList.Add(user);
            }, user =>
            {
                Console.WriteLine("…………");
                user.ChangeScole(-5);
                noFindStudentList.Add(user);
            });
            
            ConsoleResult(arrivedStudentList, noFindStudentList);
            Console.WriteLine("按任意键结束");
            Console.ReadKey();
        }

        #region 初始化人员名单数据

        /// <summary>
        /// 初始化人员名单数据
        /// </summary>
        private static List<Student> Init()
        {
            return new List<Student>()
            {
                new Student("小虎", Gender.Boy, 18, 10),
                new Student("小蛇", Gender.Girl, 17, 30),
                new Student("小龙", Gender.Boy, 19, 10),
            };
        }

        #endregion

        #region 点名系统

        /// <summary>
        /// 点名系统
        /// </summary>
        /// <param name="allUserList">全部用户</param>
        /// <param name="arrivedAction">已到用户回调</param>
        /// <param name="noFindAction">未到的用户回调</param>
        private static void SignIn(List<Student> allUserList, Action<Student> arrivedAction,
            Action<Student> noFindAction)
        {
            allUserList.ForEach(user =>
            {
                Console.WriteLine($"{user.Name}在吗？");
                if (Console.ReadLine() == "1")
                {
                    arrivedAction?.Invoke(user);
                }
                else
                {
                    noFindAction?.Invoke(user);
                }
            });
        }

        #endregion

        #region 输出点名结果

        /// <summary>
        /// 输出点名结果
        /// </summary>
        /// <param name="arrivedStudentList">已到人员集合</param>
        /// <param name="noFindStudentList">未到人员集合</param>
        private static void ConsoleResult(List<Student> arrivedStudentList, List<Student> noFindStudentList)
        {
            if (noFindStudentList.Count > 0)
            {
                Console.WriteLine("下面是未到同学名单");
                noFindStudentList.ForEach(item =>
                {
                    Console.WriteLine(
                        $"{item.Name},性别：{(item.Gender.Name)}，年龄:{item.Age}，小红花数量:{item.Scole}");
                });
            }
            else
            {
                Console.WriteLine("大家真棒，全部都到齐了，目前大家的信息如下");
                arrivedStudentList.ForEach(item =>
                {
                    Console.WriteLine(
                        $"{item.Name},性别：{(item.Gender.Name)}，年龄:{item.Age}，小红花数量:{item.Scole}");
                });
            }
        }

        #endregion
    }
}