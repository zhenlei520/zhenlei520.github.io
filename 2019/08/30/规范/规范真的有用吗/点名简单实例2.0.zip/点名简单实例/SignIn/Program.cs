﻿using System;
using System.Collections.Generic;
using System.Linq;
using EInfrastructure.Core.Configuration.Enumeration;
using SignIn.Domain;
using SignIn.Extension;

namespace SignIn
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Student> allUserList = Init(); //初始化数据
            List<Student> noFindStudentList = new List<Student>(); //未到人员集合

            Console.WriteLine("您是牛老师吗？");
            Provider provider = GetProvider(Console.ReadLine());
            Console.WriteLine("上课了，开始点名了，已到请按1，未到请按任意键");

            SignIn(provider.GetList(allUserList, provider.GetNumber()), user => { Console.WriteLine("在"); }, user =>
            {
                Console.WriteLine("…………");
                noFindStudentList.Add(user);
            });

            allUserList.ForEach(user =>
            {
                if (noFindStudentList.Any(x => x.Name == user.Name))
                {
                    user.ChangeScole(-5);
                }
                else
                {
                    user.ChangeScole(+5);
                }
            });

            ConsoleResult(allUserList, noFindStudentList);
            Console.WriteLine("按任意键结束");
            Console.ReadKey();
        }

        #region 初始化人员名单数据

        /// <summary>
        /// 初始化人员名单数据
        /// </summary>
        private static List<Student> Init()
        {
            return new List<Student>()
            {
                new Student("小虎", Gender.Boy, 18, 10),
                new Student("小蛇", Gender.Girl, 17, 30),
                new Student("小龙", Gender.Boy, 19, 10),
                new Student("小兔", Gender.Girl, 20, 25),
            };
        }

        #endregion

        #region 得到点到人数信息

        /// <summary>
        /// 得到点到人数信息
        /// </summary>
        /// <param name="res"></param>
        /// <returns></returns>
        private static Provider GetProvider(string res)
        {
            if (res == "1")
            {
                return new RandomProvider();
            }
            else
            {
                return new TraditionProvider();
            }
        }

        #endregion

        #region 点名系统

        /// <summary>
        /// 点名系统
        /// </summary>
        /// <param name="allUserList">全部用户</param>
        /// <param name="arrivedAction">已到用户回调</param>
        /// <param name="noFindAction">未到的用户回调</param>
        private static void SignIn(List<Student> allUserList, Action<Student> arrivedAction,
            Action<Student> noFindAction)
        {
            allUserList.ForEach(user =>
            {
                Console.WriteLine($"{user.Name}在吗？");
                if (Console.ReadLine() == "1")
                {
                    arrivedAction?.Invoke(user);
                }
                else
                {
                    noFindAction?.Invoke(user);
                }
            });
        }

        #endregion

        #region 输出点名结果

        /// <summary>
        /// 输出点名结果
        /// </summary>
        /// <param name="studentList">人员集合</param>
        /// <param name="noFindStudentList">未到人员集合</param>
        private static void ConsoleResult(List<Student> studentList, List<Student> noFindStudentList)
        {
            Console.WriteLine("下面是同学信息");
            studentList.ForEach(item =>
            {
                Console.WriteLine(
                    $"{item.Name},性别：{(item.Gender.Name)}，年龄:{item.Age}，小红花数量:{item.Scole}");
            });
            if (noFindStudentList.Count == 0)
            {
                Console.WriteLine("大家真棒，全部都到齐了，目前大家的信息如下");
            }
        }

        #endregion
    }
}