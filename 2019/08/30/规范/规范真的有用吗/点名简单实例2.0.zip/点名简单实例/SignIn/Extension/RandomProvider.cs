﻿using System;
using System.Collections.Generic;
using System.Linq;
using SignIn.Domain;

namespace SignIn.Extension
{
    /// <summary>
    /// 随机抽人答到
    /// </summary>
    public class RandomProvider : Provider
    {
        /// <summary>
        /// 得到被抽的学生信息集合
        /// </summary>
        /// <param name="userList">原学生集合</param>
        /// <param name="number">点到人数，-1不限人数</param>
        /// <returns></returns>
        public override List<Student> GetList(List<Student> userList, int number = -1)
        {
            if (number == -1)
            {
                return userList;
            }

            List<Student> list = new List<Student>();
            for (int i = 0; i < number && i < userList.Count; i++)
            {
                list.Add(userList.Except(list).ToList()[new Random().Next(0, userList.Except(list).ToList().Count)]);
            }

            return list;
        }

        /// <summary>
        /// 得到点到人数
        /// </summary>
        /// <returns></returns>
        public override int GetNumber()
        {
            return 3;
        }
    }
}