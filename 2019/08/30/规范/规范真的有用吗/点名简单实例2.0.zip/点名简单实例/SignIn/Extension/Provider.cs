﻿using System.Collections.Generic;
using SignIn.Domain;

namespace SignIn.Extension
{
    public abstract class Provider
    {
        /// <summary>
        /// 得到被抽的学生信息集合
        /// </summary>
        /// <param name="userList">原学生集合</param>
        /// <param name="number">点到人数，-1为不限</param>
        /// <returns></returns>
        public abstract List<Student> GetList(List<Student> userList, int number=-1);

        /// <summary>
        /// 得到点到人数
        /// </summary>
        /// <returns></returns>
        public abstract int GetNumber();
    }
}