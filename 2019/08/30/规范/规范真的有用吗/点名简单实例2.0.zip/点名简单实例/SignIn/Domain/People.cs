﻿using EInfrastructure.Core.Configuration.Enumeration;
namespace SignIn.Domain
{
    public class People
    {
        public People(){}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name">姓名</param>
        /// <param name="gender">性别</param>
        /// <param name="age">年龄</param>
        public People(string name, Gender gender, int age)
        {
            Name = name;
            Gender = gender;
            Age = age;
        }
        
        /// <summary>
        /// 姓名
        /// </summary>
        public string Name { get; private set; }

        /// <summary>
        /// 性别
        /// </summary>
        public Gender Gender { get;private set; }

        /// <summary>
        /// 年龄
        /// </summary>
        public int Age { get;private set; }
    }
}