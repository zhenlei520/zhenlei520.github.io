﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Test1
{
    /// <summary>
    /// 点名系统
    /// </summary>
    class Program
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {
            List<User> a = new List<User>()
            {
                new User()
                {
                    xingming = "小虎",
                    xingbie = true,
                    nianling = 18,
                    xiaohonghua = 10
                },
                new User()
                {
                    xingming = "小蛇",
                    xingbie = false,
                    nianling = 17,
                    xiaohonghua = 30
                },
                new User()
                {
                    xingming = "小龙",
                    xingbie = true,
                    nianling = 19,
                    xiaohonghua = 20
                },
                new User()
                {
                    xingming = "小兔",
                    xingbie = false,
                    nianling = 20,
                    xiaohonghua = 25
                }
            };
            List<User> yd = new List<User>();
            List<User> wd = new List<User>();
            Console.WriteLine("您是牛老师？如是请按1，否则请按其按任意键");
            if (Console.ReadLine() == "1")
            {
                Console.WriteLine("上课了，开始点名了，已到请按1，未到请按任意键");
                List<User> luckUserList = new List<User>();
                luckUserList.Add(
                    a.Except(luckUserList).ToList()[
                        new Random().Next(0, a.Count - luckUserList.Count - 1)]);
                luckUserList.Add(
                    a.Except(luckUserList).ToList()[
                        new Random().Next(0, a.Count - luckUserList.Count - 1)]);
                luckUserList.Add(
                    a.Except(luckUserList).ToList()[
                        new Random().Next(0, a.Count - luckUserList.Count - 1)]);
                a.ForEach(item =>
                {
                    if (luckUserList.Any(x => x.xingming == item.xingming))
                    {
                        Console.WriteLine(item.xingming + "在吗？");
                        if (Console.ReadLine() != "1")
                        {
                            Console.WriteLine("…………");
                            item.xiaohonghua = item.xiaohonghua - 5;
                            wd.Add(item);
                            return;
                        }
                    }

                    item.xiaohonghua = item.xiaohonghua + 5;
                    yd.Add(item);
                });
            }
            else
            {
                Console.WriteLine("上课了，开始点名了，已到请按1，未到请按任意键");
                a.ForEach(item =>
                {
                    Console.WriteLine(item.xingming + "在吗？");
                    if (Console.ReadLine() == "1")
                    {
                        Console.WriteLine("在");
                        item.xiaohonghua = item.xiaohonghua + 5;
                        yd.Add(item);
                    }
                    else
                    {
                        Console.WriteLine("…………");
                        item.xiaohonghua = item.xiaohonghua - 5;
                        wd.Add(item);
                    }
                });
            }

            Console.WriteLine("下面是同学信息");
            a.ForEach(item =>
            {
                Console.WriteLine(
                    $"{item.xingming},性别：{(item.xingbie ? "男" : "女")}，年龄:{item.nianling}，小红花数量:{item.xiaohonghua}");
            });
            if (wd.Count == 0)
            {
                Console.WriteLine("大家真棒，全部都到齐了，目前大家的信息如下");
            }

            Console.WriteLine("按任意键结束");
            Console.ReadKey();
        }

        public class User
        {
            public string xingming { get; set; }

            public bool xingbie { get; set; }

            public int nianling { get; set; }

            public int xiaohonghua { get; set; }
        }
    }
}